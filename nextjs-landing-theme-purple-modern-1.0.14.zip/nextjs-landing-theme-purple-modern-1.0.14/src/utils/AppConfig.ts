export const AppConfig = {
  site_name: 'Starter',
  title: 'Nextjs Starter',
  description:
    'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolore ducimus animi perferendis, placeat fugit.',
  locale: 'en',
};
